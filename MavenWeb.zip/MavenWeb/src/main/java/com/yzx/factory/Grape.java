package com.yzx.factory;

public class Grape implements Fruit{

	@Override
	public void grow() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void harverst() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void plant() {
		// TODO Auto-generated method stub
		
	}

}
