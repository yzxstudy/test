package com.yzx.factory;

public class Demo {

	private static final FruitGardener ԰�� = new FruitGardener();
	public static void main(String[] args) {
		
		
		԰��.getFruit("ƻ��").grow();
		

	}

}
