package com.yzx.mapper;

import com.yzx.bean.Student;

public interface StudentMapper {

	public Student findStudentByid(Integer studentId);
}
